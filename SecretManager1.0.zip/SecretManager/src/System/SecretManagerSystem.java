package System;

import java.util.ArrayList;

import Object.Secretinfor;
import Object.User;

public class SecretManagerSystem {
	private SecretInforControl secretinforcontrol;
    private  UserControl userControl;
	public SecretManagerSystem()
	{
		secretinforcontrol = new SecretInforControl();
		userControl= new UserControl();
	}
	
	public boolean register(User user)
	{
		boolean state = false ;
		state=userControl.register(user);
        return state;
	}
	public boolean login(User user)
	{
		boolean state = false;
		state=userControl.login(user);
		return state;
	}
	public ArrayList<Secretinfor> getinfor(String type)
	{
		ArrayList<Secretinfor> secretinforlist=secretinforcontrol.getinfor(type);
		
		return secretinforlist;
	}
	public boolean add(Secretinfor secretinfor)
	{
		boolean state = true;
		state=secretinforcontrol.add(secretinfor);
		return state;
	}
	public boolean merge(Secretinfor secretinfor,Secretinfor secretinformerge)
	{
		boolean state = false;
		secretinformerge.setId(secretinfor.getId());
		state = secretinforcontrol.merge(secretinformerge);
		return state;
		
    }
	
	public boolean delete(Integer id)
	{
		boolean state = false;
		state = secretinforcontrol.delete(id);
		return state;
	}
	
	
	
}
