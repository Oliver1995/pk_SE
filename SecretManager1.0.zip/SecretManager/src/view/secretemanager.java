package view;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.SwingUtilities;

import Object.User;
import System.SecretManagerSystem;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class secretemanager extends javax.swing.JFrame {
	private JPanel button;
	private JButton registerbut;
	private JButton jButton1;
	private JPanel register;
	private JLabel usernametext_register;
	private JTextField loadname;
	private JLabel passwordlabel;
	private JLabel loadnamelabel;
	private JPanel loadpanel;
	private JButton delectbut;
	private JButton loadsure;
	private JButton registersure;
	private JButton deletesure;
	private JTextField jTextField6;
	private JLabel jLabel2;
	private JPanel deletpanel;
	private JEditorPane jEditorPane1;
	private JPanel addpane;
	private JPasswordField againPassword;
	private JPasswordField passwordtext_re;
	private JPasswordField passwordtext;
	private JTable webtable;
	private JScrollPane web1;
	private JLabel web;
	private JLabel jLabel1;
	private JTable jTable1;
	private JScrollPane software;
	private JPanel find;
	private JTextField user_register;
	private JLabel againpassword_register;
	private JLabel passwordtext_register;
	private JButton addbut;
	private JButton load;
	private SecretManagerSystem  secretmanagersystem;
	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				
				secretemanager inst = new secretemanager();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public secretemanager() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			secretmanagersystem = new SecretManagerSystem();
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			getContentPane().setLayout(null);
			this.setVisible(false);
			{
				button = new JPanel();
				getContentPane().add(button);
				button.setBounds(0, 55, 91, 220);
				button.setLayout(null);
				{
					load = new JButton();
					button.add(load);
					load.setText("\u767b\u5f55");
					load.setBounds(0, 2, 91, 41);
					load.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							loadMouseClicked(evt);
						}
					});
				}
				{
					registerbut = new JButton();
					button.add(registerbut);
					registerbut.setText("\u6ce8\u518c");
					registerbut.setBounds(0, 39, 91, 34);
				}
				{
					addbut = new JButton();
					button.add(addbut);
					addbut.setText("\u6dfb\u52a0");
					addbut.setBounds(0, 73, 91, 37);
				}
				{
					jButton1 = new JButton();
					button.add(jButton1);
					jButton1.setText("\u4fee\u6539");
					jButton1.setBounds(0, 110, 91, 41);
				}
				{
					delectbut = new JButton();
					button.add(delectbut);
					delectbut.setText("\u5220\u9664");
					delectbut.setBounds(0, 151, 91, 45);
				}
			}
			{
				loadpanel = new JPanel();
				getContentPane().add(loadpanel);
				loadpanel.setBounds(98, 62, 266, 188);
				loadpanel.setLayout(null);
				loadpanel.setBackground(new java.awt.Color(128,128,128));
				{
					loadnamelabel = new JLabel();
					loadpanel.add(loadnamelabel);
					loadnamelabel.setText("\u7528\u6237\u540d\uff1a");
					loadnamelabel.setBounds(36, 53, 53, 24);
				}
				{
					passwordlabel = new JLabel();
					loadpanel.add(passwordlabel);
					passwordlabel.setText("\u5bc6\u7801\uff1a");
					passwordlabel.setBounds(36, 118, 38, 15);
				}
				{
					loadname = new JTextField();
					loadpanel.add(loadname);
					loadname.setText("a");
					loadname.setBounds(89, 53, 90, 22);
				}
				{
					passwordtext = new JPasswordField();
					loadpanel.add(passwordtext);
					passwordtext.setText("a");
					passwordtext.setBounds(86, 118, 93, 22);
				}
				{
					loadsure = new JButton();
					loadpanel.add(loadsure);
					loadsure.setText("\u786e\u5b9a");
					loadsure.setBounds(172, 149, 69, 30);
					loadsure.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							loadsureMouseClicked(evt);
						}
					});
					
					
					
				}
			}
			{
				register = new JPanel();
				getContentPane().add(register);
				register.setBounds(100, 56, 236, 190);
				register.setEnabled(false);
				register.setLayout(null);
				register.setVisible(false);
				{
					usernametext_register = new JLabel();
					register.add(usernametext_register);
					usernametext_register.setText("\u7528\u6237\u540d");
					usernametext_register.setBounds(19, 45, 71, 15);
				}
				{
					passwordtext_register = new JLabel();
					register.add(passwordtext_register);
					passwordtext_register.setText("\u5bc6\u7801");
					passwordtext_register.setBounds(19, 80, 42, 15);
				}
				{
					againpassword_register = new JLabel();
					register.add(againpassword_register);
					againpassword_register.setText("\u786e\u8ba4\u5bc6\u7801");
					againpassword_register.setBounds(19, 111, 51, 15);
				}
				{
					user_register = new JTextField();
					register.add(user_register);
					user_register.setText("b");
					user_register.setBounds(69, 42, 100, 22);
				}
				{
					passwordtext_re = new JPasswordField();
					register.add(passwordtext_re);
					passwordtext_re.setText("b");
					passwordtext_re.setBounds(70, 77, 99, 23);
				}
				{
					againPassword = new JPasswordField();
					register.add(againPassword);
					againPassword.setText("b");
					againPassword.setBounds(70, 108, 99, 22);
				}
				{
					registersure = new JButton();
					register.add(registersure);
					registersure.setText("\u786e\u5b9a");
					registersure.setBounds(139, 146, 72, 33);
					registersure.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							registersureMouseClicked(evt);
						}
					});
				}
			}
			{
				find = new JPanel();
				getContentPane().add(find);
				find.setBounds(94, 60, 290, 199);
				find.setLayout(null);
				find.setVisible(false);
				{
					web1 = new JScrollPane();
					find.add(web1);
					web1.setBounds(-5, 136, 288, 45);
					{
						TableModel webtableModel = 
								new DefaultTableModel(
										new String[][] { { "", "", "", "","","","" } },
										new String[] { "ID","�û���","����" ,"URL","�˻���","����","��ע" });
						webtable = new JTable();
						web1.setViewportView(webtable);
						webtable.setModel(webtableModel);
						webtable.setPreferredSize(new java.awt.Dimension(197, 32));
						webtable.setCellSelectionEnabled(true);
						webtable.setColumnSelectionAllowed(true);
					}
				}
				{
					software = new JScrollPane();
					find.add(software);
					software.setBounds(0, 22, 283, 59);
					{
						TableModel jTable1Model = 
								new DefaultTableModel(
										new String[][] { { "", "", "", "","","","" } },
										new String[] { "ID","�û���","����" ,"URL","�˻���","����","��ע" });
						jTable1 = new JTable();
						software.setViewportView(jTable1);
						jTable1.setModel(jTable1Model);
						jTable1.setPreferredSize(new java.awt.Dimension(197, 32));
						jTable1.setCellSelectionEnabled(true);
						jTable1.setColumnSelectionAllowed(true);
					}
				}
				{
					jLabel1 = new JLabel();
					find.add(jLabel1);
					jLabel1.setText("software");
					jLabel1.setBounds(5, 6, 83, 17);
					jLabel1.setFont(new java.awt.Font("����",0,14));
				}
				{
					web = new JLabel();
					find.add(web);
					web.setText("web");
					web.setBounds(5, 116, 54, 14);
					web.setFont(new java.awt.Font("����",0,14));
				}
				
			}
			{
				jEditorPane1 = new JEditorPane();
				getContentPane().add(jEditorPane1);
				jEditorPane1.setText("\u6b22\u8fce\u4f7f\u7528\u5c0f\u5bc6\u4eb2\uff0c\u8bf7\u5148\u767b\u5f55");
				jEditorPane1.setBounds(5, 12, 86, 37);
			}
			{
				deletpanel = new JPanel();
				getContentPane().add(deletpanel);
				deletpanel.setBounds(97, 61, 253, 181);
				deletpanel.setLayout(null);
				deletpanel.setVisible(false);
				{
					jLabel2 = new JLabel();
					deletpanel.add(jLabel2);
					jLabel2.setText("\u5220\u9664\u6761\u76ee\u7684ID");
					jLabel2.setBounds(5, 56, 97, 15);
				}
				{
					jTextField6 = new JTextField();
					deletpanel.add(jTextField6);
					jTextField6.setText("3");
					jTextField6.setBounds(102, 53, 103, 22);
				}
				{
					deletesure = new JButton();
					deletpanel.add(deletesure);
					deletesure.setText("\u786e\u5b9a");
					deletesure.setBounds(146, 116, 44, 26);
					deletesure.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent evt) {
							deletesureMouseClicked(evt);
						}
					});
				}
			}
			pack();
			setSize(400, 300);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	
	
	private void deletesureMouseClicked(MouseEvent evt) {
		Integer id = Integer.parseInt(jTextField6.getText());
		secretmanagersystem.delete(id);
		//TODO add your code for deletesure.mouseClicked
	}
	
	private void registersureMouseClicked(MouseEvent evt) {
		User user=new User(user_register.getText(),passwordtext_re.getText());
		secretmanagersystem.register(user);
		//TODO add your code for deletesure.mouseClicked
	}
	private void loadsureMouseClicked(MouseEvent evt) {
		User user=new User(user_register.getText(),passwordtext_re.getText());
		secretmanagersystem.login(user);
		//TODO add your code for deletesure.mouseClicked
	}
	private void loadMouseClicked(MouseEvent evt) {
		loadpanel.setVisible(true);
		//TODO add your code for deletesure.mouseClicked
	}

}
