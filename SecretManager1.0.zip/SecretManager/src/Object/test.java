package Object;

import java.util.ArrayList;

import DAO.SecretinforDAO;
import DAO.UserDAO;
import System.SecretManagerSystem;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean state = true ;
		Integer index=3 ;
		SecretManagerSystem secretmanagersystem = new SecretManagerSystem();
		//User user = new User("db","239483042");
//		state = secretmanagersystem.register(user);
//		System.out.println(state);
//		state = secretmanagersystem.login(user);
//		System.out.println(state);
		Secretinfor secretinfor = new Secretinfor("d", "software",null, "qq","a","a");
		Secretinfor secretinfor1 = new Secretinfor("d", "soft",null, "pipi","a","a");
		secretinfor.setId(index);
		//state= secretmanagersystem.add(secretinfor);
		//System.out.println(state);
//		ArrayList<Secretinfor> secretinforlist = secretmanagersystem.getinfor("software");
//		System.out.println(secretinforlist.size());
//		state= secretmanagersystem.merge(secretinfor,secretinfor1);
//		System.out.println(state);
		state= secretmanagersystem.delete(index);
		System.out.println(state);
 }
	
	
}
