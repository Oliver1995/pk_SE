package System;

import DAO.UserDAO;
import Object.User;

public class UserControl {
	UserDAO userdao;
	
     public UserControl()
     {
    	 userdao=new UserDAO();
     }
	public boolean register(User user)
	{
		boolean state = false ;
		if(userdao.findById(user.getUsername())==null)
		{
			userdao.save(user);
			state = true;
			return state;
		}
		return state;
	}
	public boolean login(User user)
	{
		boolean state = false;
		User usertemp = new User();
		usertemp=userdao.findById(user.getUsername());
		if(usertemp!= null )
		{
			if(usertemp.getPassword().equals(user.getPassword()))
			{
				state = true;
			}
		}
		return state;
	}
	
}
