package System;

import java.util.ArrayList;

import DAO.SecretinforDAO;
import Object.Secretinfor;

public class SecretInforControl {
	public SecretinforDAO secretinfordao;
	private ArrayList<Secretinfor> secretinforlist;
	public SecretInforControl()
	{
		secretinfordao= new SecretinforDAO();
	}
	public ArrayList<Secretinfor> getinfor(String type)
	{
		secretinforlist=(ArrayList<Secretinfor>)secretinfordao.findByType(type);
		
		return secretinforlist;
	}
	public boolean add(Secretinfor secretinfor)
	{
		boolean state = true;
		int i=0;
		ArrayList<Secretinfor> secretinforlist=(ArrayList<Secretinfor>)secretinfordao.findByUsername(secretinfor.getUsername());
		if(secretinforlist!=null)
		{
			for(i=0;i<secretinforlist.size();i++)
			{
				if(secretinforlist.get(i).getUrl()==secretinfor.getUrl())
				{
					if(secretinforlist.get(i).getAccount()==secretinfor.getAccount())
					{
						state = false;
						return state;
					}
				}
			}
		}
		secretinfordao.save(secretinfor);
		return state;
	}
	public boolean merge(Secretinfor secretinfor)
	{
		boolean state = false;
		if(secretinfordao.findById(secretinfor.getId()) == null)
		{
			return state;
		}
		secretinfordao.merge(secretinfor);
		state= true;
		return state;
		
    }
	
	public boolean delete(Integer id)
	{
		boolean state = false;
		if(secretinfordao.findById(id) == null)
		{
			return state;
		}
		Secretinfor seretinfortemp;
		seretinfortemp=secretinfordao.findById(id);
		secretinfordao.delete(seretinfortemp);
		state= true;
		return state;
	}
	

}