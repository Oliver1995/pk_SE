package DAO;

import java.util.List;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import Object.Secretinfor;

/**
 * A data access object (DAO) providing persistence and search support for
 * Secretinfor entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see DAO.Secretinfor
 * @author MyEclipse Persistence Tools
 */
public class SecretinforDAO extends BaseHibernateDAO {
	private static final Logger log = LoggerFactory
			.getLogger(SecretinforDAO.class);
	// property constants
	public static final String USERNAME = "username";
	public static final String TYPE = "type";
	public static final String COMMENT = "comment";
	public static final String URL = "url";
	public static final String ACCOUNT = "account";
	public static final String PASSWORD = "password";
	public Transaction tx;
	public void save(Secretinfor transientInstance) {
		log.debug("saving Secretinfor instance");
		tx=getSession().beginTransaction();
		try {
			getSession().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
		tx.commit();
	}

	public void delete(Secretinfor persistentInstance) {
		tx=getSession().beginTransaction();
		log.debug("deleting Secretinfor instance");
		try {
			getSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
		tx.commit();
	}

	public Secretinfor findById(java.lang.Integer id) {
		log.debug("getting Secretinfor instance with id: " + id);
		try {
			Secretinfor instance = (Secretinfor) getSession().get(
					"Object.Secretinfor", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Secretinfor instance) {
		log.debug("finding Secretinfor instance by example");
		try {
			List results = getSession().createCriteria("DAO.Secretinfor")
					.add(Example.create(instance)).list();
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Secretinfor instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Secretinfor as model where model."
					+ propertyName + "= ?";
			Query queryObject = getSession().createQuery(queryString);
			queryObject.setParameter(0, value);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByUsername(Object username) {
		return findByProperty(USERNAME, username);
	}

	public List findByType(Object type) {
		return findByProperty(TYPE, type);
	}

	public List findByComment(Object comment) {
		return findByProperty(COMMENT, comment);
	}

	public List findByUrl(Object url) {
		return findByProperty(URL, url);
	}

	public List findByAccount(Object account) {
		return findByProperty(ACCOUNT, account);
	}

	public List findByPassword(Object password) {
		return findByProperty(PASSWORD, password);
	}

	public List findAll() {
		log.debug("finding all Secretinfor instances");
		try {
			String queryString = "from Secretinfor";
			Query queryObject = getSession().createQuery(queryString);
			return queryObject.list();
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Secretinfor merge(Secretinfor detachedInstance) {
		tx=getSession().beginTransaction();
		log.debug("merging Secretinfor instance");
		try {
			Secretinfor result = (Secretinfor) getSession().merge(
					detachedInstance);
			log.debug("merge successful");
			tx.commit();
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	
	}

	public void attachDirty(Secretinfor instance) {
		log.debug("attaching dirty Secretinfor instance");
		try {
			getSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Secretinfor instance) {
		log.debug("attaching clean Secretinfor instance");
		try {
			getSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
}